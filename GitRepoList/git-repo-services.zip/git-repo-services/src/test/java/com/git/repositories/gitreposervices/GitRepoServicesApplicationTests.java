package com.git.repositories.gitreposervices;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GitRepoServicesApplicationTests {

	@Test
	void contextLoads() {
	}

}
